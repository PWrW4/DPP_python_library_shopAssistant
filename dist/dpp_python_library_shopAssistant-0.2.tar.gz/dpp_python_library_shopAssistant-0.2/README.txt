This is python library. Created for lesson on PWr W4 DPP.

Created based on https://github.com/BillMills/pythonPackageLesson

create package `python setup.py sdist`

install `pip install git+ssh://bitbucket.org/pwr_w4_inf/dpp_python_library_shopassistant`