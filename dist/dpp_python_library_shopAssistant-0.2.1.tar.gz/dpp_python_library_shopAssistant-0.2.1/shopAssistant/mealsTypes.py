from enum import Enum


class MealType(Enum):
    Breakfast = 1
    Lunch = 2
    Dinner = 3
    All = 4
