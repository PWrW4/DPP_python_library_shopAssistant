This is python library. Created for lesson on PWr W4 DPP.

Created based on https://github.com/BillMills/pythonPackageLesson